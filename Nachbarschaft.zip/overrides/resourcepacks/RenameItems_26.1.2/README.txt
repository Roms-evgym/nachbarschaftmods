Rename Items – Minecraft Java 26.1.2 Vanilla

This pack demonstrates name-based item model selection.

Supported item:
- Diamond Sword → rename exactly to "Excalibur"
- Diamond Sword → rename exactly to "Ruby Sword"

Important:
Minecraft 26.1.x uses resource-pack version 84. The item-model system is data-driven.
The two custom models currently use the vanilla diamond-sword texture as a safe placeholder.
Replace the model/texture files in assets/renameitems/ to make them visually different.

Install:
1. Put RenameItems_26.1.2.zip into .minecraft/resourcepacks
2. Open Minecraft → Options → Resource Packs
3. Enable the pack
4. Rename a Diamond Sword in an anvil to exactly "Excalibur" or "Ruby Sword".

If your 26.1.2 build rejects the component-select syntax, Minecraft's exact 26.1.2 item-model schema differs from the documented 26.1 snapshot schema and the JSON needs the final-release field names adjusted.
